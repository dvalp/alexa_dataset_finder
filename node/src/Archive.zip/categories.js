module.exports = {
  "earth science": "earth science",
  "public saftey": "public saftey",
  "government": "government",
  "social services": "social services",
  "health": "health",
  "transportation": "transportation",
  "city government": "city government",
  "education": "education",
  "loan and credit administration": "loan and credit administration",
  "energy and environment": "energy and environment"
};
